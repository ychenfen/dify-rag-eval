#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
RAG 知识库检索评测工具
支持 Dify 知识库的召回率、精确率、F1、MRR 等指标评测
"""

import os
import json
import time
import requests
import pandas as pd
import numpy as np
from typing import List, Dict, Tuple, Optional
from dataclasses import dataclass, field
from dotenv import load_dotenv
from tqdm import tqdm
from datetime import datetime

# 加载环境变量
load_dotenv()


@dataclass
class RetrievalResult:
    """单次检索结果"""
    query: str
    retrieved_docs: List[Dict]  # 检索到的文档列表
    gold_doc_ids: List[str]     # 标准答案文档ID列表
    is_hit: bool = False        # 是否命中
    hit_rank: int = -1          # 首次命中的排名（-1表示未命中）
    latency_ms: float = 0       # 检索耗时（毫秒）


@dataclass
class EvaluationMetrics:
    """评测指标"""
    total_queries: int = 0
    hit_count: int = 0
    recall_at_k: float = 0.0
    precision_at_k: float = 0.0
    f1_at_k: float = 0.0
    mrr: float = 0.0
    avg_latency_ms: float = 0.0
    hit_distribution: Dict[int, int] = field(default_factory=dict)  # 各排名命中数分布


class DifyRetriever:
    """Dify 知识库检索器"""

    def __init__(self, api_base: str = None, api_key: str = None):
        """
        初始化检索器

        Args:
            api_base: API基础URL
            api_key: API密钥
        """
        self.api_base = api_base or os.getenv('DIFY_API_BASE', 'https://api.dify.ai/v1')
        self.api_key = api_key or os.getenv('DIFY_API_KEY')

        if not self.api_key:
            raise ValueError("未配置 DIFY_API_KEY，请在 .env 文件中设置")

        self.headers = {
            'Authorization': f'Bearer {self.api_key}',
            'Content-Type': 'application/json'
        }

    def retrieve(self, dataset_id: str, query: str, top_k: int = 5,
                 score_threshold: float = 0.0) -> Tuple[List[Dict], float]:
        """
        执行检索

        Args:
            dataset_id: 知识库ID
            query: 查询问题
            top_k: 返回结果数量
            score_threshold: 分数阈值

        Returns:
            (检索结果列表, 耗时毫秒)
        """
        url = f"{self.api_base}/datasets/{dataset_id}/retrieve"

        payload = {
            "query": query,
            "retrieval_model": {
                "search_method": "semantic_search",  # 语义检索
                "reranking_enable": False,  # 是否启用重排
                "top_k": top_k,
                "score_threshold_enabled": score_threshold > 0,
                "score_threshold": score_threshold
            }
        }

        start_time = time.time()

        try:
            response = requests.post(url, headers=self.headers, json=payload, timeout=30)
            latency_ms = (time.time() - start_time) * 1000

            if response.status_code != 200:
                print(f"检索失败: {response.status_code} - {response.text}")
                return [], latency_ms

            data = response.json()
            records = data.get('records', [])

            # 标准化结果格式
            results = []
            for i, record in enumerate(records):
                results.append({
                    'rank': i + 1,
                    'document_id': record.get('segment', {}).get('document_id', ''),
                    'segment_id': record.get('segment', {}).get('id', ''),
                    'content': record.get('segment', {}).get('content', ''),
                    'score': record.get('score', 0),
                    'document_name': record.get('segment', {}).get('document', {}).get('name', ''),
                })

            return results, latency_ms

        except Exception as e:
            latency_ms = (time.time() - start_time) * 1000
            print(f"检索异常: {str(e)}")
            return [], latency_ms

    def retrieve_with_rerank(self, dataset_id: str, query: str, top_k: int = 5,
                             rerank_model: str = "bge-reranker-base") -> Tuple[List[Dict], float]:
        """
        执行带重排的检索

        Args:
            dataset_id: 知识库ID
            query: 查询问题
            top_k: 返回结果数量
            rerank_model: 重排模型名称

        Returns:
            (检索结果列表, 耗时毫秒)
        """
        url = f"{self.api_base}/datasets/{dataset_id}/retrieve"

        payload = {
            "query": query,
            "retrieval_model": {
                "search_method": "semantic_search",
                "reranking_enable": True,
                "reranking_model": {
                    "reranking_provider_name": "local",
                    "reranking_model_name": rerank_model
                },
                "top_k": top_k,
                "score_threshold_enabled": False
            }
        }

        start_time = time.time()

        try:
            response = requests.post(url, headers=self.headers, json=payload, timeout=60)
            latency_ms = (time.time() - start_time) * 1000

            if response.status_code != 200:
                print(f"检索失败: {response.status_code} - {response.text}")
                return [], latency_ms

            data = response.json()
            records = data.get('records', [])

            results = []
            for i, record in enumerate(records):
                results.append({
                    'rank': i + 1,
                    'document_id': record.get('segment', {}).get('document_id', ''),
                    'segment_id': record.get('segment', {}).get('id', ''),
                    'content': record.get('segment', {}).get('content', ''),
                    'score': record.get('score', 0),
                    'document_name': record.get('segment', {}).get('document', {}).get('name', ''),
                })

            return results, latency_ms

        except Exception as e:
            latency_ms = (time.time() - start_time) * 1000
            print(f"检索异常: {str(e)}")
            return [], latency_ms


class RAGEvaluator:
    """RAG 检索评测器"""

    def __init__(self, retriever: DifyRetriever):
        """
        初始化评测器

        Args:
            retriever: 检索器实例
        """
        self.retriever = retriever
        self.results: List[RetrievalResult] = []

    def load_evaluation_set(self, file_path: str) -> pd.DataFrame:
        """
        加载评测集

        Args:
            file_path: 评测集文件路径（支持xlsx、csv）

        Returns:
            评测集DataFrame
        """
        if file_path.endswith('.xlsx'):
            df = pd.read_excel(file_path, engine='openpyxl')
        elif file_path.endswith('.csv'):
            df = pd.read_csv(file_path)
        else:
            raise ValueError(f"不支持的文件格式: {file_path}")

        # 验证必要列
        required_columns = ['query', 'gold_doc_id']
        for col in required_columns:
            if col not in df.columns:
                raise ValueError(f"评测集缺少必要列: {col}")

        print(f"加载评测集: {len(df)} 条记录")
        return df

    def evaluate(self, dataset_id: str, evaluation_set: pd.DataFrame,
                 top_k: int = 5, use_rerank: bool = False,
                 rerank_model: str = None) -> EvaluationMetrics:
        """
        执行评测

        Args:
            dataset_id: 知识库ID
            evaluation_set: 评测集DataFrame
            top_k: TopK值
            use_rerank: 是否使用重排
            rerank_model: 重排模型（use_rerank=True时需要）

        Returns:
            评测指标
        """
        self.results = []
        hit_count = 0
        total_rr = 0  # 用于计算MRR
        total_latency = 0
        hit_distribution = {i: 0 for i in range(1, top_k + 1)}

        print(f"\n开始评测...")
        print(f"知识库ID: {dataset_id}")
        print(f"TopK: {top_k}")
        print(f"使用重排: {use_rerank}")
        print(f"评测集大小: {len(evaluation_set)}")
        print("-" * 50)

        for idx, row in tqdm(evaluation_set.iterrows(), total=len(evaluation_set), desc="评测进度"):
            query = str(row['query'])

            # 处理gold_doc_id（可能是单个或多个，用逗号分隔）
            gold_doc_ids = [doc_id.strip() for doc_id in str(row['gold_doc_id']).split(',')]

            # 执行检索
            if use_rerank and rerank_model:
                retrieved_docs, latency = self.retriever.retrieve_with_rerank(
                    dataset_id, query, top_k, rerank_model
                )
            else:
                retrieved_docs, latency = self.retriever.retrieve(dataset_id, query, top_k)

            total_latency += latency

            # 判断是否命中
            is_hit = False
            hit_rank = -1

            for doc in retrieved_docs:
                doc_id = doc.get('document_id', '')
                if doc_id in gold_doc_ids:
                    is_hit = True
                    hit_rank = doc['rank']
                    break

            if is_hit:
                hit_count += 1
                total_rr += 1.0 / hit_rank
                hit_distribution[hit_rank] = hit_distribution.get(hit_rank, 0) + 1

            # 记录结果
            result = RetrievalResult(
                query=query,
                retrieved_docs=retrieved_docs,
                gold_doc_ids=gold_doc_ids,
                is_hit=is_hit,
                hit_rank=hit_rank,
                latency_ms=latency
            )
            self.results.append(result)

            # 避免请求过快
            time.sleep(0.1)

        # 计算指标
        total_queries = len(evaluation_set)
        recall = hit_count / total_queries if total_queries > 0 else 0
        precision = hit_count / (top_k * total_queries) if total_queries > 0 else 0
        f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0
        mrr = total_rr / total_queries if total_queries > 0 else 0
        avg_latency = total_latency / total_queries if total_queries > 0 else 0

        metrics = EvaluationMetrics(
            total_queries=total_queries,
            hit_count=hit_count,
            recall_at_k=recall,
            precision_at_k=precision,
            f1_at_k=f1,
            mrr=mrr,
            avg_latency_ms=avg_latency,
            hit_distribution=hit_distribution
        )

        return metrics

    def get_detailed_results(self) -> pd.DataFrame:
        """
        获取详细结果

        Returns:
            详细结果DataFrame
        """
        data = []
        for r in self.results:
            data.append({
                'query': r.query,
                'gold_doc_ids': ','.join(r.gold_doc_ids),
                'is_hit': r.is_hit,
                'hit_rank': r.hit_rank if r.hit_rank > 0 else 'N/A',
                'latency_ms': round(r.latency_ms, 2),
                'top1_doc_id': r.retrieved_docs[0]['document_id'] if r.retrieved_docs else '',
                'top1_score': round(r.retrieved_docs[0]['score'], 4) if r.retrieved_docs else '',
                'top1_content': r.retrieved_docs[0]['content'][:100] if r.retrieved_docs else '',
            })
        return pd.DataFrame(data)

    def save_results(self, metrics: EvaluationMetrics, output_dir: str,
                     config_name: str = "default"):
        """
        保存评测结果

        Args:
            metrics: 评测指标
            output_dir: 输出目录
            config_name: 配置名称（用于区分不同实验）
        """
        os.makedirs(output_dir, exist_ok=True)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

        # 保存指标摘要
        summary = {
            'config_name': config_name,
            'timestamp': timestamp,
            'total_queries': metrics.total_queries,
            'hit_count': metrics.hit_count,
            'recall_at_k': round(metrics.recall_at_k, 4),
            'precision_at_k': round(metrics.precision_at_k, 4),
            'f1_at_k': round(metrics.f1_at_k, 4),
            'mrr': round(metrics.mrr, 4),
            'avg_latency_ms': round(metrics.avg_latency_ms, 2),
            'hit_distribution': metrics.hit_distribution
        }

        summary_file = os.path.join(output_dir, f"metrics_{config_name}_{timestamp}.json")
        with open(summary_file, 'w', encoding='utf-8') as f:
            json.dump(summary, f, ensure_ascii=False, indent=2)
        print(f"指标摘要已保存: {summary_file}")

        # 保存详细结果
        detailed_df = self.get_detailed_results()
        detailed_file = os.path.join(output_dir, f"detailed_{config_name}_{timestamp}.xlsx")
        detailed_df.to_excel(detailed_file, index=False, engine='openpyxl')
        print(f"详细结果已保存: {detailed_file}")

        return summary_file, detailed_file


def print_metrics(metrics: EvaluationMetrics, config_name: str = ""):
    """
    打印评测指标

    Args:
        metrics: 评测指标
        config_name: 配置名称
    """
    print("\n" + "=" * 50)
    if config_name:
        print(f"配置: {config_name}")
    print("=" * 50)
    print(f"总查询数:      {metrics.total_queries}")
    print(f"命中数:        {metrics.hit_count}")
    print(f"Recall@K:      {metrics.recall_at_k:.4f} ({metrics.recall_at_k*100:.2f}%)")
    print(f"Precision@K:   {metrics.precision_at_k:.4f} ({metrics.precision_at_k*100:.2f}%)")
    print(f"F1@K:          {metrics.f1_at_k:.4f}")
    print(f"MRR:           {metrics.mrr:.4f}")
    print(f"平均延迟:      {metrics.avg_latency_ms:.2f} ms")
    print("-" * 50)
    print("命中排名分布:")
    for rank, count in sorted(metrics.hit_distribution.items()):
        if count > 0:
            print(f"  Rank {rank}: {count} ({count/metrics.total_queries*100:.1f}%)")
    print("=" * 50)


if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser(description='RAG 知识库检索评测工具')
    parser.add_argument('--dataset-id', type=str, required=True, help='知识库ID')
    parser.add_argument('--eval-set', type=str, required=True, help='评测集文件路径')
    parser.add_argument('--top-k', type=int, default=5, help='TopK值')
    parser.add_argument('--use-rerank', action='store_true', help='是否使用重排')
    parser.add_argument('--rerank-model', type=str, default='bge-reranker-base', help='重排模型')
    parser.add_argument('--output-dir', type=str, default='./results', help='输出目录')
    parser.add_argument('--config-name', type=str, default='default', help='配置名称')

    args = parser.parse_args()

    # 初始化
    retriever = DifyRetriever()
    evaluator = RAGEvaluator(retriever)

    # 加载评测集
    eval_set = evaluator.load_evaluation_set(args.eval_set)

    # 执行评测
    metrics = evaluator.evaluate(
        dataset_id=args.dataset_id,
        evaluation_set=eval_set,
        top_k=args.top_k,
        use_rerank=args.use_rerank,
        rerank_model=args.rerank_model if args.use_rerank else None
    )

    # 打印结果
    print_metrics(metrics, args.config_name)

    # 保存结果
    evaluator.save_results(metrics, args.output_dir, args.config_name)

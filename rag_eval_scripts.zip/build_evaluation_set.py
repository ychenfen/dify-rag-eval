#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
评测集构建工具
用于从知识库文档中生成候选问题，辅助人工标注
"""

import os
import json
import pandas as pd
from dotenv import load_dotenv
import requests
from tqdm import tqdm

# 加载环境变量
load_dotenv()

class EvaluationSetBuilder:
    """评测集构建器"""

    def __init__(self):
        self.api_base = os.getenv('DIFY_API_BASE', 'https://api.dify.ai/v1')
        self.api_key = os.getenv('DIFY_API_KEY')
        self.headers = {
            'Authorization': f'Bearer {self.api_key}',
            'Content-Type': 'application/json'
        }

    def get_dataset_documents(self, dataset_id: str) -> list:
        """
        获取知识库中的所有文档列表

        Args:
            dataset_id: 知识库ID

        Returns:
            文档列表
        """
        url = f"{self.api_base}/datasets/{dataset_id}/documents"
        all_documents = []
        page = 1

        while True:
            params = {'page': page, 'limit': 20}
            response = requests.get(url, headers=self.headers, params=params)

            if response.status_code != 200:
                print(f"获取文档列表失败: {response.text}")
                break

            data = response.json()
            documents = data.get('data', [])

            if not documents:
                break

            all_documents.extend(documents)

            if not data.get('has_more', False):
                break

            page += 1

        print(f"共获取到 {len(all_documents)} 个文档")
        return all_documents

    def get_document_segments(self, dataset_id: str, document_id: str) -> list:
        """
        获取文档的所有分段

        Args:
            dataset_id: 知识库ID
            document_id: 文档ID

        Returns:
            分段列表
        """
        url = f"{self.api_base}/datasets/{dataset_id}/documents/{document_id}/segments"
        all_segments = []
        page = 1

        while True:
            params = {'page': page, 'limit': 100}
            response = requests.get(url, headers=self.headers, params=params)

            if response.status_code != 200:
                print(f"获取分段失败: {response.text}")
                break

            data = response.json()
            segments = data.get('data', [])

            if not segments:
                break

            all_segments.extend(segments)

            if not data.get('has_more', False):
                break

            page += 1

        return all_segments

    def extract_candidate_questions(self, segment_text: str) -> list:
        """
        从文本段落中提取候选问题
        基于规则的简单提取，可以替换为更智能的方法

        Args:
            segment_text: 段落文本

        Returns:
            候选问题列表
        """
        import jieba

        questions = []

        # 规则1: 如果段落包含"问："或"Q:"，直接提取
        if '问：' in segment_text or 'Q:' in segment_text or 'Q：' in segment_text:
            lines = segment_text.split('\n')
            for line in lines:
                if line.startswith('问：') or line.startswith('Q:') or line.startswith('Q：'):
                    q = line.replace('问：', '').replace('Q:', '').replace('Q：', '').strip()
                    if q:
                        questions.append(q)

        # 规则2: 提取标题类内容作为候选问题
        lines = segment_text.split('\n')
        for line in lines:
            line = line.strip()
            # 匹配标题格式
            if line and len(line) < 50:
                # 去除序号
                import re
                clean_line = re.sub(r'^[\d一二三四五六七八九十]+[\.、\s]', '', line)
                if clean_line and len(clean_line) > 4:
                    # 转换为问句
                    if not clean_line.endswith('?') and not clean_line.endswith('？'):
                        questions.append(f"{clean_line}是什么")
                        questions.append(f"如何{clean_line}")

        return questions[:5]  # 每个段落最多返回5个候选问题

    def build_candidate_set(self, dataset_id: str, output_file: str = 'candidate_questions.xlsx'):
        """
        构建候选评测集

        Args:
            dataset_id: 知识库ID
            output_file: 输出文件名
        """
        print("开始构建候选评测集...")

        # 获取所有文档
        documents = self.get_dataset_documents(dataset_id)

        candidates = []

        for doc in tqdm(documents, desc="处理文档"):
            doc_id = doc['id']
            doc_name = doc.get('name', 'unknown')

            # 获取文档分段
            segments = self.get_document_segments(dataset_id, doc_id)

            for seg in segments:
                seg_id = seg.get('id', '')
                seg_text = seg.get('content', '')

                if not seg_text:
                    continue

                # 提取候选问题
                questions = self.extract_candidate_questions(seg_text)

                for q in questions:
                    candidates.append({
                        'id': len(candidates) + 1,
                        'query': q,
                        'gold_doc_id': doc_id,
                        'gold_doc_name': doc_name,
                        'gold_segment_id': seg_id,
                        'gold_chunk_text': seg_text[:200],  # 截取前200字符
                        'category': '',  # 待人工填写
                        'difficulty': '',  # 待人工填写
                        'is_valid': '',  # 待人工确认（Y/N）
                    })

        # 保存到Excel
        df = pd.DataFrame(candidates)
        df.to_excel(output_file, index=False, engine='openpyxl')

        print(f"候选评测集已保存到: {output_file}")
        print(f"共生成 {len(candidates)} 条候选问题")
        print("请人工审核并标注 is_valid、category、difficulty 列")

        return df


def create_empty_template(output_file: str = 'evaluation_set_template.xlsx'):
    """
    创建空的评测集模板

    Args:
        output_file: 输出文件名
    """
    template = pd.DataFrame({
        'id': [1, 2, 3],
        'query': ['示例问题1：年假有多少天', '示例问题2：怎么申请报销', '示例问题3：试用期多长'],
        'gold_doc_id': ['doc_001', 'doc_002', 'doc_003'],
        'gold_chunk_text': ['员工入职满一年可享受5天带薪年假', '报销流程：填写报销单后提交审批', '试用期一般为3个月'],
        'category': ['请假', '报销', '入职'],
        'difficulty': ['easy', 'medium', 'easy'],
    })

    template.to_excel(output_file, index=False, engine='openpyxl')
    print(f"评测集模板已创建: {output_file}")
    print("请按模板格式填写您的评测数据")


if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser(description='评测集构建工具')
    parser.add_argument('--action', choices=['template', 'build'], default='template',
                        help='操作类型: template-创建空模板, build-从知识库构建')
    parser.add_argument('--dataset-id', type=str, help='知识库ID（build模式需要）')
    parser.add_argument('--output', type=str, default='evaluation_set.xlsx', help='输出文件名')

    args = parser.parse_args()

    if args.action == 'template':
        create_empty_template(args.output)
    elif args.action == 'build':
        if not args.dataset_id:
            print("错误: build模式需要指定 --dataset-id")
            exit(1)
        builder = EvaluationSetBuilder()
        builder.build_candidate_set(args.dataset_id, args.output)
